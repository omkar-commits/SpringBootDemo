package org.springapp;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootTestApp {

	public static void main(String[] args) 
	{
		SpringApplication.run(SpringBootTestApp.class, args);   
	}
}